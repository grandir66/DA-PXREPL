import { createRouter, createWebHistory } from 'vue-router'
import Dashboard from '../views/Dashboard.vue'
import Nodes from '../views/Nodes.vue'
import VMs from '../views/VMs.vue'
import MigrationJobs from '../views/jobs/MigrationJobs.vue'
import Logs from '../views/Logs.vue'
import Settings from '../views/Settings.vue'
import Login from '../views/Login.vue'
import MainLayout from '../layouts/MainLayout.vue'

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes: [
        {
            path: '/login',
            name: 'login',
            component: Login
        },
        {
            path: '/',
            component: MainLayout,
            meta: { requiresAuth: true },
            children: [
                {
                    path: '',
                    name: 'dashboard',
                    component: Dashboard
                },
                {
                    path: 'nodes',
                    name: 'nodes',
                    component: Nodes
                },
                {
                    path: 'vms',
                    name: 'vms',
                    component: VMs
                },
                {
                    path: 'replication',
                    name: 'replication',
                    component: () => import('../views/Replication.vue')
                },
                {
                    path: 'file-replication',
                    name: 'file-replication',
                    component: () => import('../views/FileReplication.vue')
                },
                {
                    path: 'vm-snapshots',
                    name: 'vm-snapshots',
                    component: () => import('../views/VmSnapshots.vue')
                },
                {
                    path: 'nas-sync',
                    name: 'nas-sync',
                    component: () => import('../views/NasSync.vue')
                },
                {
                    path: 'sanoid-syncoid',
                    name: 'sanoid-syncoid',
                    component: () => import('../views/SanoidSyncoid.vue')
                },
                // Legacy routes → modulo unificato Repliche
                { path: 'sync-jobs', redirect: { name: 'replication' } },
                { path: 'backup-jobs', redirect: { name: 'pbs-backup', query: { tab: 'jobs' } } },
                { path: 'recovery-jobs', redirect: { name: 'replication' } },
                {
                    path: 'pbs-backup',
                    name: 'pbs-backup',
                    component: () => import('../views/PBSBackup.vue')
                },
                {
                    path: 'pbs-inventory',
                    redirect: to => ({
                        name: 'pbs-backup',
                        query: { ...to.query, tab: to.query.tab || 'inventory' },
                    }),
                },
                {
                    path: 'host-backup',
                    name: 'host-backup',
                    component: () => import('../views/HostBackupView.vue')
                },
                {
                    path: 'migration-jobs',
                    name: 'migration-jobs',
                    component: MigrationJobs
                },
                {
                    path: 'logs',
                    name: 'logs',
                    component: Logs
                },
                {
                    path: 'settings',
                    name: 'settings',
                    component: Settings
                },
                {
                    path: 'updates',
                    name: 'updates',
                    meta: { requiresAdmin: true },
                    component: () => import('../views/settings/Updates.vue')
                },
                {
                    path: 'config-backup',
                    name: 'config-backup',
                    meta: { requiresAdmin: true },
                    component: () => import('../views/settings/ConfigBackup.vue')
                },
                { path: 'load-balancer', redirect: { name: 'cluster' } },
                {
                    path: 'cluster',
                    name: 'cluster',
                    component: () => import('../views/Cluster.vue')
                },
            ]
        },
    ]
})

router.beforeEach(async (to, _from, next) => {
    const isAuthenticated = localStorage.getItem('access_token')
    if (to.meta.requiresAuth && !isAuthenticated) {
        next({ name: 'login' })
        return
    }
    if (to.meta.requiresAdmin) {
        let user: { role?: string } | null = null
        try {
            user = JSON.parse(localStorage.getItem('user') || 'null')
        } catch {
            user = null
        }
        if (user?.role !== 'admin') {
            next({ name: 'dashboard' })
            return
        }
    }
    next()
})

export default router
