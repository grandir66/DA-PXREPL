import apiClient from './api'

export interface User {
    id: number;
    username: string;
    email?: string;
    full_name?: string;
    role?: string;
    is_active?: boolean;
}

export interface LoginResponse {
    access_token: string;
    refresh_token: string;
    token_type: string;
    expires_in: number;
    user: User;
}

export default {
    login(credentials: any) {
        return apiClient.post<LoginResponse>('/auth/login', {
            username: credentials.username,
            password: credentials.password,
            realm: credentials.realm
        });
    },

    getMe() {
        return apiClient.get<User>('/auth/me');
    },

    getRealms() {
        return apiClient.get('/auth/realms');
    },

    getConfig() {
        return apiClient.get('/auth/config');
    },

    setup(data: any) {
        return apiClient.post('/auth/setup', data);
    },

    // Admin User Management
    getUsers() {
        return apiClient.get<User[]>('/auth/users');
    },

    createUser(data: any) {
        return apiClient.post<User>('/auth/users', data);
    },

    deleteUser(id: number | string) {
        return apiClient.delete(`/auth/users/${id}`);
    },

    // Password Management
    changePassword(data: any) {
        return apiClient.put('/auth/me/password', data);
    }
}
